"""Device ID D.O. Notice Generator"""
import os
from docx.shared import Pt
from .base import (new_doc, do_header, para, brief_facts_block,
                   add_table, io_block, s94_quote, FONT)

GOOGLE_ADDRESS = [
    "Google LLC",
    "1600 Amphitheatre Parkway,",
    "Mountain View, California — 94043, USA",
    "Email: india-nodal-officer@google.com",
]


def generate_device_id(common):
    device_ids = common.get("device_ids") or _collect()

    doc = new_doc()
    do_header(doc, GOOGLE_ADDRESS, common["notice_date"])

    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(
        f"Request for Device ID Information in FIR No. {common['fir_no']} — "
        f"{common['ps']}, Delhi"
    )
    for r in p.runs:
        r.font.name = FONT; r.font.size = Pt(12)

    para(doc, ""); para(doc, "Dear Sir/Ma'am,"); para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run(
        "In connection with the above-mentioned FIR, information is required for "
        "the following Device ID(s) (Android Device IDs / W-Series IDs):"
    )
    p2.runs[0].font.name = FONT; p2.runs[0].font.size = Pt(12)
    para(doc, "")

    add_table(doc,
        headers=["Sr.", "Device ID"],
        rows=[(i+1, d) for i, d in enumerate(device_ids)],
        col_widths=[0.5, 5.0])

    para(doc, "")
    brief_facts_block(doc, common["fir_no"], common["ps"], common["district"],
                      common["victim_name"], common["amount"],
                      common["date_of_fir"], common["sections"])

    p3 = doc.add_paragraph()
    p3.add_run("You are requested to provide:").bold = True
    p3.runs[0].font.name = FONT; p3.runs[0].font.size = Pt(12)

    for pt in [
        "Login and logout logs with date, time, and IP address.",
        "All Google/Gmail accounts linked to the above Device ID(s).",
        "Device registration details: manufacturer, model, IMEI, and Android version.",
        "Session details and geolocation data associated with the device.",
        "VPN / proxy usage indicators.",
        "Linked recovery email, phone number, and backup accounts.",
        "Google Pay (GPay) transactions linked to the device.",
        "Preserve all data related to the above Device ID(s).",
        "Comply as per Section 63(4) PSS Act, 2007.",
    ]:
        p = doc.add_paragraph(style="List Number")
        p.add_run(pt); p.runs[0].font.name = FONT; p.runs[0].font.size = Pt(12)

    s94_quote(doc)
    io_block(doc, common["io_name"], common["io_rank"],
             common["io_phone"], common["io_email"], common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/DeviceID_{common['fir_no'].replace('/','_')}.docx"
    doc.save(fname)
    return fname


def _collect():
    ids = []
    idx = 1
    while True:
        d = input(f"  [{idx}] Device ID (blank=done): ").strip()
        if not d: break
        ids.append(d); idx += 1
    return ids
