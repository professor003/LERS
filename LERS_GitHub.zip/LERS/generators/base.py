"""
Base document helpers for LERS notice generators.
Font standard: Times New Roman 12pt throughout (as per LEA formatting norms).
"""

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


FONT = "Times New Roman"
FONT_SIZE = Pt(12)
DARK = RGBColor(0x0D, 0x1F, 0x3C)

S94_BNSS = (
    "Section 94 of Bharatiya Nagarik Suraksha Sanhita, 2023 (BNSS): "
    '"Whenever any Court or any officer in charge of a police station considers '
    "that the production of any document, electronic communication or other thing "
    "is necessary or desirable for the purposes of any investigation, inquiry, trial "
    "or other proceeding under this Code by or before such Court or officer, such "
    "Court may issue a summons, or such officer a written order, to the person in "
    "whose possession or power such document, electronic communication or other "
    "thing is believed to be, requiring him to attend and produce it, or to produce "
    'it, at the time and place stated in the summons or order."'
)


def new_doc():
    doc = Document()
    # Set page margins (1 inch all sides)
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1.2)
        sec.right_margin  = Inches(1.2)
    # Remove default styles clutter
    style = doc.styles["Normal"]
    style.font.name = FONT
    style.font.size = FONT_SIZE
    return doc


def heading(doc, text, size=14, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, color=None):
    p = doc.add_paragraph()
    p.alignment = align
    run = p.add_run(text)
    run.bold = bold
    run.font.name = FONT
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = color
    return p


def para(doc, text, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT, size=12):
    p = doc.add_paragraph()
    p.alignment = align
    run = p.add_run(text)
    run.bold = bold
    run.font.name = FONT
    run.font.size = Pt(size)
    return p


def divider(doc):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("─" * 70)
    run.font.name = FONT
    run.font.size = Pt(10)
    run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
    return p


def letterhead(doc, to_name, notice_no, notice_date):
    """Standard letterhead block."""
    heading(doc, "OFFICE OF THE INVESTIGATING OFFICER", size=13, bold=True)
    heading(doc, "IFSO Special Cell, Delhi Police", size=12, bold=False)
    divider(doc)

    # Notice number + date
    p = doc.add_paragraph()
    p.add_run(f"Notice No.: {notice_no}").bold = True
    p.add_run(f"\t\t\t\t\t\tDate: {notice_date}")
    p.runs[-1].font.name = FONT
    p.runs[0].font.name = FONT

    para(doc, "")
    para(doc, f"To,")
    para(doc, f"{to_name}", bold=True)
    para(doc, "")


def do_header(doc, to_address, notice_date):
    """D.O. (Demi-Official) letter header — no notice number."""
    heading(doc, "DEMI-OFFICIAL LETTER", size=13, bold=True)
    heading(doc, "IFSO Special Cell, Delhi Police", size=12, bold=False)
    divider(doc)
    para(doc, f"Date: {notice_date}")
    para(doc, "")
    para(doc, "To,")
    for line in to_address:
        para(doc, line, bold=False)
    para(doc, "")


def brief_facts_block(doc, fir_no, ps, district, victim, amount, date_fir, sections):
    """Standard brief facts paragraph."""
    para(doc, "BRIEF FACTS OF THE CASE:", bold=True)
    text = (
        f"That an FIR bearing No. {fir_no} has been registered at P.S. {ps}, "
        f"Distt. {district}, Delhi, against unknown accused person(s) on the complaint "
        f"of Sh./Smt. {victim}. The complainant has alleged that he/she has been "
        f"defrauded of an amount of ₹{amount}/- by the accused person(s) through "
        f"fraudulent means. The FIR has been registered under Sections {sections} of "
        f"BNS/IT Act, 2000. Date of FIR: {date_fir}."
    )
    para(doc, text)
    para(doc, "")


def urgent_marking(doc):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("*** MOST URGENT & SECRET ***")
    run.bold = True
    run.font.name = FONT
    run.font.size = Pt(13)
    run.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)
    return p


def io_block(doc, io_name, io_rank, io_phone, io_email, ps):
    """IO sign-off block at bottom of notice."""
    para(doc, "")
    para(doc, "Kindly cooperate and provide the above-mentioned information at the earliest.", bold=False)
    para(doc, "")
    p = doc.add_paragraph()
    p.add_run("Yours faithfully,\n\n\n")
    p.add_run(f"{io_name}\n").bold = True
    p.add_run(f"{io_rank}\n").bold = True
    p.add_run(f"P.S. {ps}\n")
    p.add_run(f"📞 {io_phone}   ✉ {io_email}")
    for run in p.runs:
        run.font.name = FONT
        run.font.size = FONT_SIZE


def s94_quote(doc):
    """Mandatory S.94 BNSS verbatim quote for D.O. letters."""
    para(doc, "")
    para(doc, "Legal Authority:", bold=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    run = p.add_run(S94_BNSS)
    run.font.name = FONT
    run.font.size = Pt(11)
    run.italic = True


def add_table(doc, headers, rows, col_widths=None):
    """Add a formatted table."""
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"

    # Header row
    hrow = table.rows[0]
    for i, h in enumerate(headers):
        cell = hrow.cells[i]
        cell.text = h
        cell.paragraphs[0].runs[0].bold = True
        cell.paragraphs[0].runs[0].font.name = FONT
        cell.paragraphs[0].runs[0].font.size = FONT_SIZE
        # Header shading
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "D9E1F2")
        tcPr.append(shd)

    # Data rows
    for ri, row_data in enumerate(rows):
        row = table.rows[ri + 1]
        for ci, val in enumerate(row_data):
            cell = row.cells[ci]
            cell.text = str(val)
            cell.paragraphs[0].runs[0].font.name = FONT
            cell.paragraphs[0].runs[0].font.size = FONT_SIZE

    # Column widths
    if col_widths:
        for i, width in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Inches(width)

    return table


def mla_note(doc):
    """MP/MLA note appended to CDR/ILD notices."""
    para(doc, "")
    p = doc.add_paragraph()
    run = p.add_run(
        "Note: In case the mobile number(s) belong to any Member of Parliament (MP) / "
        "Member of Legislative Assembly (MLA) / Judicial Officer, kindly inform this "
        "office before providing the data, as prior permission of the competent "
        "authority is required."
    )
    run.italic = True
    run.font.name = FONT
    run.font.size = Pt(11)
