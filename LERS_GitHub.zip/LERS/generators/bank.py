"""Bank Account Lien + Statement Notice Generator"""

import os
from docx.shared import Pt
from .base import (new_doc, letterhead, heading, para, divider,
                   brief_facts_block, add_table, io_block,
                   urgent_marking, FONT)


def collect(common):
    print("\n  ── Bank Notice Details ───────────────────────────")
    bank_name = input("  Bank Name: ").strip()
    layer     = input("  Layer (e.g. L1/L2/L3 or 'Suspect'): ").strip()
    print("  Enter account details (blank account no. to finish):")
    accounts = []
    idx = 1
    while True:
        acc  = input(f"    [{idx}] Account No.: ").strip()
        if not acc:
            break
        ifsc = input(f"    [{idx}] IFSC Code  : ").strip()
        lien = input(f"    [{idx}] Lien Amt ₹ : ").strip()
        accounts.append((acc, ifsc, lien))
        idx += 1
    return bank_name, layer, accounts


def generate_bank(common):
    if "bank_name" not in common:
        bank_name, layer, accounts = collect(common)
    else:
        bank_name = common["bank_name"]
        layer     = common.get("layer", "Suspect")
        accounts  = [(a["account_no"], a["ifsc"], a.get("lien_amount", "0"))
                     for a in common["accounts"]]

    doc = new_doc()
    urgent_marking(doc)
    para(doc, "")
    letterhead(
        doc,
        to_name=f"The Nodal Officer / Cybercell\n{bank_name}\n[Branch Address]",
        notice_no=common["notice_no"],
        notice_date=common["notice_date"],
    )

    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(
        f"Notice to provide details of Bank Account ({layer}) in "
        f"FIR No. {common['fir_no']} — {common['ps']}, Delhi"
    )
    for r in p.runs:
        r.font.name = FONT
        r.font.size = Pt(12)

    para(doc, "")
    para(doc, "Sir/Ma'am,")
    para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run(
        "You are hereby directed to provide the following information in connection "
        "with the above-mentioned FIR. The accounts detailed below are involved in "
        "the commission of the alleged cybercrime/fraud:"
    )
    p2.runs[0].font.name = FONT
    p2.runs[0].font.size = Pt(12)
    para(doc, "")

    add_table(
        doc,
        headers=["Sr.", "Account No.", "IFSC Code", "Lien Amount (₹)"],
        rows=[(i+1, a[0], a[1], a[2]) for i, a in enumerate(accounts)],
        col_widths=[0.4, 2.0, 1.5, 1.5],
    )

    para(doc, "")
    brief_facts_block(doc,
        fir_no=common["fir_no"], ps=common["ps"], district=common["district"],
        victim=common["victim_name"], amount=common["amount"],
        date_fir=common["date_of_fir"], sections=common["sections"])

    p3 = doc.add_paragraph()
    p3.add_run("You are requested to provide:").bold = True
    p3.runs[0].font.name = FONT
    p3.runs[0].font.size = Pt(12)

    points = [
        f"Place a lien / freeze on the above-mentioned account(s) for the amount specified.",
        "Provide complete account statement from account opening date to date.",
        "Provide KYC documents: account opening form, ID proof, address proof, photographs.",
        "Provide IP address, device fingerprint, and login logs used for net banking / UPI transactions.",
        "Provide details of all linked debit/credit cards, mobile numbers, and email IDs.",
        "Provide information as mandated under Section 63(4) of the Payment and Settlement Systems Act, 2007.",
        "Provide details of any other accounts linked to the same mobile number / Aadhaar / PAN.",
    ]
    for pt in points:
        p = doc.add_paragraph(style="List Number")
        p.add_run(pt)
        p.runs[0].font.name = FONT
        p.runs[0].font.size = Pt(12)

    io_block(doc,
        io_name=common["io_name"], io_rank=common["io_rank"],
        io_phone=common["io_phone"], io_email=common["io_email"],
        ps=common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/Bank_{common['fir_no'].replace('/', '_')}_{bank_name.replace(' ', '_')}.docx"
    doc.save(fname)
    return fname
