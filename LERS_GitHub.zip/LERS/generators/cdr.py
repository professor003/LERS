"""CDR / IPDR Notice Generator — S.94 BNSS / Telegraph Act"""

import os
from docx.enum.text import WD_ALIGN_PARAGRAPH
from .base import (new_doc, letterhead, heading, para, divider,
                   brief_facts_block, add_table, mla_note, io_block,
                   urgent_marking, FONT)
from docx.shared import Pt


def collect(common):
    print("\n  ── CDR / IPDR Details ────────────────────────────")
    tsp = input("  TSP Name (Jio/Airtel/Vi/BSNL): ").strip()
    print("  Enter mobile numbers (blank line to finish):")
    entries = []
    idx = 1
    while True:
        mob = input(f"    [{idx}] Mobile No.: ").strip()
        if not mob:
            break
        frm = input(f"    [{idx}] From Date (DD/MM/YYYY): ").strip()
        to  = input(f"    [{idx}] To Date   (DD/MM/YYYY): ").strip()
        entries.append((mob, frm, to, common["fir_no"]))
        idx += 1
    return tsp, entries


def generate_cdr(common):
    if "tsp" not in common:
        tsp, entries = collect(common)
    else:
        tsp     = common["tsp"]
        entries = [(e["mobile"], e["from"], e["to"], common["fir_no"])
                   for e in common["entries"]]

    doc = new_doc()
    urgent_marking(doc)
    para(doc, "")
    letterhead(
        doc,
        to_name=f"The Nodal Officer\n{tsp}\n[Address]",
        notice_no=common["notice_no"],
        notice_date=common["notice_date"],
    )

    # Subject
    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(
        f"Request for Call Detail Records (CDR) / Internet Protocol Detail Records "
        f"(IPDR) under Section 94 BNSS / Section 92 Indian Telegraph Act in "
        f"FIR No. {common['fir_no']}"
    )
    for run in p.runs:
        run.font.name = FONT
        run.font.size = Pt(12)

    para(doc, "")
    para(doc, "Sir/Ma'am,")
    para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run(
        "Kindly provide the CDR/IPDR of the following mobile number(s) in connection "
        "with the above-mentioned FIR registered at this office, under Section 94 "
        "BNSS / Section 92 of the Indian Telegraph Act, 1885:"
    )
    p2.runs[0].font.name = FONT
    p2.runs[0].font.size = Pt(12)
    para(doc, "")

    add_table(
        doc,
        headers=["Sr.", "Mobile No.", "From Date", "To Date", "FIR No."],
        rows=[(i+1, e[0], e[1], e[2], e[3]) for i, e in enumerate(entries)],
        col_widths=[0.4, 1.4, 1.3, 1.3, 2.0],
    )

    para(doc, "")
    brief_facts_block(doc,
        fir_no=common["fir_no"], ps=common["ps"], district=common["district"],
        victim=common["victim_name"], amount=common["amount"],
        date_fir=common["date_of_fir"], sections=common["sections"])

    p3 = doc.add_paragraph()
    p3.add_run("You are further requested to:").bold = True
    p3.runs[0].font.name = FONT
    p3.runs[0].font.size = Pt(12)

    for point in [
        "Provide CDR (voice/SMS) and IPDR (data sessions) including IMEI, cell tower IDs, and geolocation data.",
        "Provide CAF / subscriber registration details for the above numbers.",
        "Preserve all records pertaining to the above numbers until further notice.",
        "Respond within 3 working days as this is an urgent law enforcement matter.",
    ]:
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(point)
        p.runs[0].font.name = FONT
        p.runs[0].font.size = Pt(12)

    mla_note(doc)
    io_block(doc,
        io_name=common["io_name"], io_rank=common["io_rank"],
        io_phone=common["io_phone"], io_email=common["io_email"],
        ps=common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/CDR_{common['fir_no'].replace('/', '_')}_{tsp}.docx"
    doc.save(fname)
    return fname
