"""PhonePe Notice Generator"""
import os
from docx.shared import Pt
from .base import (new_doc, letterhead, para, brief_facts_block,
                   add_table, io_block, urgent_marking, FONT)


def generate_phonepe(common):
    mobiles = common.get("mobile_numbers") or _collect()

    doc = new_doc()
    urgent_marking(doc)
    para(doc, "")
    letterhead(doc,
        to_name="The Nodal Officer / Cybercell\nPhonePe Private Limited\nEast Wing, Divyasree Technopolis, Yemalur,\nBengaluru — 560037\nEmail: cybercell@phonepe.com",
        notice_no=common["notice_no"],
        notice_date=common["notice_date"])

    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(
        f"Request for PhonePe Account & Transaction Details in "
        f"FIR No. {common['fir_no']} — {common['ps']}, Delhi"
    )
    for r in p.runs:
        r.font.name = FONT; r.font.size = Pt(12)

    para(doc, ""); para(doc, "Sir/Ma'am,"); para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run(
        "In connection with the above-mentioned FIR, kindly provide details "
        "for the following PhonePe registered mobile number(s):"
    )
    p2.runs[0].font.name = FONT; p2.runs[0].font.size = Pt(12)
    para(doc, "")

    add_table(doc,
        headers=["Sr.", "Mobile Number"],
        rows=[(i+1, m) for i, m in enumerate(mobiles)],
        col_widths=[0.5, 4.0])

    para(doc, "")
    brief_facts_block(doc, common["fir_no"], common["ps"], common["district"],
                      common["victim_name"], common["amount"],
                      common["date_of_fir"], common["sections"])

    p3 = doc.add_paragraph()
    p3.add_run("You are requested to provide:").bold = True
    p3.runs[0].font.name = FONT; p3.runs[0].font.size = Pt(12)

    for pt in [
        "All bank accounts / VPAs linked to the above mobile number(s).",
        "Complete transaction details (sent/received) with date, time, amount, UTR, and counterparty details.",
        "Geolocation (latitude/longitude) and IP address at time of each transaction.",
        "Device fingerprint (IMEI / Device ID) used for the transactions.",
        "KYC details: name, address, Aadhaar / PAN linked to the account.",
        "Any other information that may assist in the investigation.",
    ]:
        p = doc.add_paragraph(style="List Number")
        p.add_run(pt); p.runs[0].font.name = FONT; p.runs[0].font.size = Pt(12)

    io_block(doc, common["io_name"], common["io_rank"],
             common["io_phone"], common["io_email"], common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/PhonePe_{common['fir_no'].replace('/','_')}.docx"
    doc.save(fname)
    return fname


def _collect():
    mobiles = []
    idx = 1
    while True:
        m = input(f"  [{idx}] Mobile No. (blank=done): ").strip()
        if not m: break
        mobiles.append(m); idx += 1
    return mobiles
