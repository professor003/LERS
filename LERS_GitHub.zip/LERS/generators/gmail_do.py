"""Gmail / Google D.O. Letter Generator"""
import os
from docx.shared import Pt
from .base import (new_doc, do_header, para, brief_facts_block,
                   add_table, io_block, s94_quote, FONT)

GOOGLE_ADDRESS = [
    "Google LLC",
    "1600 Amphitheatre Parkway,",
    "Mountain View, California — 94043, USA",
    "Email: india-nodal-officer@google.com",
]


def generate_gmail_do(common):
    gmail_ids = common.get("gmail_ids") or _collect_ids()

    doc = new_doc()
    do_header(doc, GOOGLE_ADDRESS, common["notice_date"])

    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(
        f"Request for User/Subscriber Information of Gmail ID(s) in "
        f"FIR No. {common['fir_no']} — {common['ps']}, Delhi"
    )
    for r in p.runs:
        r.font.name = FONT; r.font.size = Pt(12)

    para(doc, ""); para(doc, "Dear Sir/Ma'am,"); para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run(
        "This is to bring to your kind attention that this office is investigating a "
        "cybercrime case registered vide FIR mentioned above. In furtherance of the "
        "investigation, information is required for the following Gmail ID(s):"
    )
    p2.runs[0].font.name = FONT; p2.runs[0].font.size = Pt(12)
    para(doc, "")

    add_table(doc,
        headers=["Sr.", "Gmail ID"],
        rows=[(i+1, g) for i, g in enumerate(gmail_ids)],
        col_widths=[0.5, 5.0])

    para(doc, "")
    brief_facts_block(doc, common["fir_no"], common["ps"], common["district"],
                      common["victim_name"], common["amount"],
                      common["date_of_fir"], common["sections"])

    p3 = doc.add_paragraph()
    p3.add_run("You are requested to provide the following information:").bold = True
    p3.runs[0].font.name = FONT; p3.runs[0].font.size = Pt(12)

    for pt in [
        "Full name, date of birth, recovery email/phone of the account registrant.",
        "Account creation date, last login date/time, and IP address logs.",
        "IMEI number, Android Device ID, and MAC address linked to the account.",
        "Preserve all records and data related to the above Gmail ID(s).",
        "Provide information as required under Section 94 BNSS and Section 63(4) PSS Act, 2007.",
    ]:
        p = doc.add_paragraph(style="List Number")
        p.add_run(pt); p.runs[0].font.name = FONT; p.runs[0].font.size = Pt(12)

    s94_quote(doc)
    io_block(doc, common["io_name"], common["io_rank"],
             common["io_phone"], common["io_email"], common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/Gmail_DO_{common['fir_no'].replace('/','_')}.docx"
    doc.save(fname)
    return fname


def _collect_ids():
    ids = []
    idx = 1
    while True:
        g = input(f"  [{idx}] Gmail ID (blank=done): ").strip()
        if not g: break
        ids.append(g); idx += 1
    return ids
