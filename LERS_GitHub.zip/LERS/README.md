# LERS — Legal Enforcement Requirement System

**Automated Legal Notice Generator for Cybercrime Investigations**

> Built by [Aniket Jha](https://linkedin.com/in/aniket-jha-4a626129a) — Cybercrime Investigator, IFSO Special Cell, Delhi Police

---

## What is LERS?

In cybercrime investigations under Indian law, Investigating Officers must draft and dispatch legal notices to banks, telecom operators, digital platforms, and foreign companies demanding subscriber data, CDRs, IPDRs, transaction records, and CCTV footage.

Manually drafting each notice takes **~20 minutes** per notice.  
With LERS, it takes **under 2 minutes**.

LERS generates fully formatted, court-ready DOCX notices under:
- **Section 94, Bharatiya Nagarik Suraksha Sanhita (BNSS), 2023**
- **Section 92, Indian Telegraph Act, 1885**
- **Section 63(4), Payment and Settlement Systems Act, 2007**

---

## Supported Notice Types

| # | Type | Target | Legal Basis |
|---|------|--------|-------------|
| 1 | CDR / IPDR Request | TSPs (Jio / Airtel / Vi / BSNL) | S.94 BNSS / Telegraph Act |
| 2 | Bank Account Notice | Banks (lien + statement + KYC) | S.94 BNSS |
| 3 | ATM CCTV Notice | Banks | S.94 BNSS / PSS Act |
| 4 | Cheque CCTV Notice | Banks | S.94 BNSS / PSS Act |
| 5 | Gmail / Google D.O. | Google LLC, USA | S.94 BNSS |
| 6 | Device ID D.O. | Google LLC, USA | S.94 BNSS |
| 7 | PhonePe Notice | PhonePe Pvt. Ltd. | S.94 BNSS |
| 8 | ILD / ILDR Search | All TSPs (auto-generates 4 notices) | S.94 BNSS / Telegraph Act |

---

## Installation

```bash
git clone https://github.com/professor003/LERS.git
cd LERS
pip install -r requirements.txt
```

**Requirements:** Python 3.8+ · python-docx

---

## Usage

### Interactive Mode (Recommended)

```bash
python lers.py
```

Follow the on-screen menu. You will be prompted for case details and notice-specific data. The generated `.docx` file is saved in the `output/` folder.

```
╔══════════════════════════════════════════════════════════════════╗
║          LERS — Legal Enforcement Requirement System            ║
║       Automated Legal Notice Generator  |  v1.0.0              ║
╚══════════════════════════════════════════════════════════════════╝

  Select Notice Type:
  ─────────────────────────────────────────────
   [1]  CDR / IPDR Request          (TSP)
   [2]  Bank Account Notice         (Bank)
   [3]  ATM CCTV Notice             (Bank)
   [4]  Cheque CCTV Notice          (Bank)
   [5]  Gmail / Google D.O.         (Google LLC)
   [6]  Device ID Notice            (Google LLC)
   [7]  PhonePe Notice              (PhonePe)
   [8]  ILD / ILDR Search           (All TSPs)
  ─────────────────────────────────────────────
   [9]  Batch Mode (from JSON file)
   [0]  Exit
```

### CLI Mode (Non-interactive)

```bash
python lers.py --type 1 --input samples/batch_sample.json
```

### Batch Mode

Generate multiple notices from a single JSON file:

```bash
# From within interactive menu, select [9]
# Or use the --input flag

python lers.py --type 9 --input samples/batch_sample.json
```

See `samples/batch_sample.json` for the JSON schema.

---

## JSON Schema

```json
{
  "type": "1",
  "notice_no": "001/2026",
  "notice_date": "28/04/2026",
  "fir_no": "123/2026",
  "ps": "Cyber South",
  "district": "South Delhi",
  "io_name": "Sub-Inspector Name",
  "io_rank": "SI",
  "io_phone": "+91 XXXXXXXXXX",
  "io_email": "io@police.gov.in",
  "victim_name": "Victim Name",
  "amount": "5,00,000",
  "date_of_fir": "15/03/2026",
  "sections": "318(4) BNS, 66C/66D IT Act",
  "tsp": "Jio",
  "entries": [
    {"mobile": "9876543210", "from": "01/01/2026", "to": "15/03/2026"}
  ]
}
```

Full schema examples for all notice types are in `samples/batch_sample.json`.

---

## Output

All notices are saved to the `output/` directory with descriptive filenames:

```
output/
├── CDR_123_2026_Jio.docx
├── Bank_123_2026_HDFC_Bank.docx
├── ATM_CCTV_123_2026_SBI.docx
├── Gmail_DO_123_2026.docx
├── PhonePe_123_2026.docx
└── ILD_123_2026_Airtel.docx
```

---

## Notice Format Standards

All generated notices follow Indian LEA formatting standards:

- **Font:** Times New Roman, 12pt throughout
- **Header:** IFSO Special Cell letterhead (configurable)
- **Tables:** Formatted with column headers and row data
- **Legal citations:** S.94 BNSS verbatim included in D.O. letters
- **Markings:** `MOST URGENT & SECRET` on bank/CCTV/PhonePe notices
- **MP/MLA note:** Appended to CDR and ILD notices
- **Sign-off:** IO name, rank, phone, email at bottom

---

## Project Structure

```
LERS/
├── lers.py                   # Main CLI entry point
├── requirements.txt
├── README.md
├── generators/
│   ├── __init__.py
│   ├── base.py               # Shared docx helpers
│   ├── cdr.py                # CDR / IPDR notices
│   ├── bank.py               # Bank account notices
│   ├── cctv_atm.py           # ATM CCTV notices
│   ├── cctv_cheque.py        # Cheque CCTV notices
│   ├── gmail_do.py           # Gmail D.O. letters
│   ├── device_id.py          # Device ID D.O. letters
│   ├── phonepe.py            # PhonePe notices
│   └── ild.py                # ILD / ILDR notices (all TSPs)
├── samples/
│   └── batch_sample.json     # Sample JSON inputs
└── output/                   # Generated notices (gitignored)
```

---

## Legal Notice

This tool is intended solely for use by authorised law enforcement personnel in India. All notices generated must be issued under valid legal authority. Misuse of this tool for unauthorised data requests is illegal under Indian law.

---

## Author

**Aniket Jha**  
Cybercrime Investigator — IFSO Special Cell, Delhi Police  
MCA — Cyber Security & Privacy, Uttaranchal University (2026)  
📧 aniketjha395@gmail.com  
🔗 [LinkedIn](https://linkedin.com/in/aniket-jha-4a626129a)

---

*Built to serve law enforcement. Not for commercial use.*
