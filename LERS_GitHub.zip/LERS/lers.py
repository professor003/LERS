#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║   LERS — Legal Enforcement Requirement System               ║
║   Automated Legal Notice Generator for Cybercrime IOs       ║
║   Author : Aniket Jha | IFSO Special Cell, Delhi Police     ║
║   GitHub : github.com/professor003                          ║
╚══════════════════════════════════════════════════════════════╝

Generates court-ready legal notices under S.94 BNSS /
Indian Telegraph Act in under 2 minutes.
"""

import os
import sys
import json
import argparse
from datetime import date
from generators.cdr        import generate_cdr
from generators.bank       import generate_bank
from generators.cctv_atm   import generate_cctv_atm
from generators.cctv_cheque import generate_cctv_cheque
from generators.gmail_do   import generate_gmail_do
from generators.device_id  import generate_device_id
from generators.phonepe    import generate_phonepe
from generators.ild        import generate_ild

BANNER = """
╔══════════════════════════════════════════════════════════════════╗
║          LERS — Legal Enforcement Requirement System            ║
║       Automated Legal Notice Generator  |  v1.0.0              ║
║       Developed by: Aniket Jha  |  github.com/professor003     ║
╚══════════════════════════════════════════════════════════════════╝
"""

MENU = """
  Select Notice Type:
  ─────────────────────────────────────────────
   [1]  CDR / IPDR Request          (TSP)
   [2]  Bank Account Notice         (Bank)
   [3]  ATM CCTV Notice             (Bank)
   [4]  Cheque CCTV Notice          (Bank)
   [5]  Gmail / Google D.O.         (Google LLC)
   [6]  Device ID Notice            (Google LLC)
   [7]  PhonePe Notice              (PhonePe)
   [8]  ILD / ILDR Search           (All TSPs)
  ─────────────────────────────────────────────
   [9]  Batch Mode (from JSON file)
   [0]  Exit
"""

GENERATORS = {
    "1": ("CDR / IPDR",          generate_cdr),
    "2": ("Bank Account Notice", generate_bank),
    "3": ("ATM CCTV",            generate_cctv_atm),
    "4": ("Cheque CCTV",         generate_cctv_cheque),
    "5": ("Gmail D.O.",          generate_gmail_do),
    "6": ("Device ID D.O.",      generate_device_id),
    "7": ("PhonePe Notice",      generate_phonepe),
    "8": ("ILD / ILDR",          generate_ild),
}


def get_common_fields():
    """Collect IO and FIR details common across all notices."""
    print("\n  ── Case Details ──────────────────────────────────")
    return {
        "fir_no"      : input("  FIR No.           : ").strip(),
        "ps"          : input("  Police Station    : ").strip(),
        "district"    : input("  District          : ").strip(),
        "io_name"     : input("  IO Name           : ").strip(),
        "io_rank"     : input("  IO Rank           : ").strip(),
        "io_phone"    : input("  IO Phone          : ").strip(),
        "io_email"    : input("  IO Email          : ").strip(),
        "victim_name" : input("  Victim Name       : ").strip(),
        "amount"      : input("  Amount (₹)        : ").strip(),
        "date_of_fir" : input("  Date of FIR       : ").strip(),
        "sections"    : input("  Sections Applied  : ").strip(),
        "notice_no"   : input("  Notice No. (blank=___): ").strip() or "___",
        "notice_date" : input(f"  Notice Date [{date.today().strftime('%d/%m/%Y')}]: ").strip()
                        or date.today().strftime("%d/%m/%Y"),
    }


def run_interactive():
    print(BANNER)
    os.makedirs("output", exist_ok=True)

    while True:
        print(MENU)
        choice = input("  Enter choice: ").strip()

        if choice == "0":
            print("\n  Exiting LERS. Stay safe.\n")
            sys.exit(0)

        if choice == "9":
            run_batch()
            continue

        if choice not in GENERATORS:
            print("  ❌  Invalid choice. Try again.")
            continue

        name, fn = GENERATORS[choice]
        print(f"\n  ── Generating: {name} ─────────────────────────────")

        common = get_common_fields()
        outpath = fn(common)
        print(f"\n  ✅  Notice saved → {outpath}\n")


def run_batch():
    path = input("\n  JSON file path: ").strip()
    if not os.path.exists(path):
        print(f"  ❌  File not found: {path}")
        return
    with open(path) as f:
        jobs = json.load(f)
    for job in jobs:
        ntype = str(job.get("type", ""))
        if ntype not in GENERATORS:
            print(f"  ⚠  Unknown type '{ntype}', skipping.")
            continue
        name, fn = GENERATORS[ntype]
        outpath = fn(job)
        print(f"  ✅  {name} → {outpath}")


def run_cli(args):
    """Non-interactive mode via --type and --input flags."""
    if args.type not in GENERATORS:
        print(f"❌ Unknown type: {args.type}. Use 1-8.")
        sys.exit(1)
    with open(args.input) as f:
        data = json.load(f)
    name, fn = GENERATORS[args.type]
    outpath = fn(data)
    print(f"✅ {name} generated → {outpath}")


def main():
    parser = argparse.ArgumentParser(
        description="LERS — Legal Enforcement Requirement System"
    )
    parser.add_argument("--type",  help="Notice type (1-8)")
    parser.add_argument("--input", help="JSON input file path")
    args = parser.parse_args()

    if args.type and args.input:
        run_cli(args)
    else:
        run_interactive()


if __name__ == "__main__":
    main()
