"""ILD / ILDR Search Notice Generator — International Call Data"""
import os
from docx.shared import Pt
from .base import (new_doc, letterhead, para, brief_facts_block,
                   add_table, mla_note, io_block, urgent_marking, FONT)

TSPS = [
    ("Jio",      "Nodal Officer, Reliance Jio Infocomm Ltd.", "nodal.mh@reliancejio.com"),
    ("Airtel",   "Nodal Officer, Bharti Airtel Ltd.",          "Nodal.MNG@airtel.com"),
    ("Vi",       "Nodal Officer, Vodafone Idea Ltd.",          "nodaldd.maharashtra@vodafoneidea.com"),
    ("BSNL",     "Nodal Officer, BSNL",                        "nodmobbsnlmh@bsnl.co.in"),
]


def generate_ild(common):
    mobiles = common.get("mobile_numbers") or _collect()
    specific_tsp = common.get("tsp")

    targets = [t for t in TSPS if not specific_tsp or t[0] == specific_tsp]

    saved = []
    for tsp_name, tsp_addr, tsp_email in targets:
        doc = new_doc()
        urgent_marking(doc)
        para(doc, "")
        letterhead(doc,
            to_name=f"{tsp_addr}\nEmail: {tsp_email}",
            notice_no=common["notice_no"],
            notice_date=common["notice_date"])

        p = doc.add_paragraph()
        p.add_run("Subject: ").bold = True
        p.add_run(
            f"Request for ILD / ILDR (International Call Data Records) under "
            f"S.94 BNSS / Telegraph Act in FIR No. {common['fir_no']}"
        )
        for r in p.runs:
            r.font.name = FONT; r.font.size = Pt(12)

        para(doc, ""); para(doc, "Sir/Ma'am,"); para(doc, "")
        p2 = doc.add_paragraph()
        p2.add_run(
            "Kindly provide the International Long Distance Records (ILD/ILDR) for "
            "the following mobile number(s) in connection with the above FIR:"
        )
        p2.runs[0].font.name = FONT; p2.runs[0].font.size = Pt(12)
        para(doc, "")

        rows = [(i+1, m["mobile"], m["from"], m["to"], common["fir_no"])
                for i, m in enumerate(mobiles)]
        add_table(doc,
            headers=["Sr.", "Mobile No.", "From Date", "To Date", "FIR No."],
            rows=rows,
            col_widths=[0.4, 1.4, 1.3, 1.3, 2.0])

        para(doc, "")
        brief_facts_block(doc, common["fir_no"], common["ps"], common["district"],
                          common["victim_name"], common["amount"],
                          common["date_of_fir"], common["sections"])

        for pt in [
            "Provide ILD/ILDR data including calling number, called number, date, time, duration, and originating country.",
            "Provide IMEI and cell tower details associated with each ILD record.",
            "Preserve all records and respond within 3 working days.",
        ]:
            p = doc.add_paragraph(style="List Number")
            p.add_run(pt); p.runs[0].font.name = FONT; p.runs[0].font.size = Pt(12)

        mla_note(doc)
        io_block(doc, common["io_name"], common["io_rank"],
                 common["io_phone"], common["io_email"], common["ps"])

        os.makedirs("output", exist_ok=True)
        fname = f"output/ILD_{common['fir_no'].replace('/','_')}_{tsp_name}.docx"
        doc.save(fname)
        saved.append(fname)

    return ", ".join(saved)


def _collect():
    mobiles = []
    idx = 1
    while True:
        mob = input(f"  [{idx}] Mobile No. (blank=done): ").strip()
        if not mob: break
        frm = input(f"  [{idx}] From Date: ").strip()
        to  = input(f"  [{idx}] To Date  : ").strip()
        mobiles.append({"mobile": mob, "from": frm, "to": to})
        idx += 1
    return mobiles
