"""ATM CCTV Notice Generator"""
import os
from docx.shared import Pt
from .base import (new_doc, letterhead, para, brief_facts_block,
                   add_table, io_block, urgent_marking, FONT)


def collect(common):
    print("\n  ── ATM CCTV Details ──────────────────────────────")
    bank = input("  Bank Name: ").strip()
    txns = []
    idx = 1
    while True:
        txn_id = input(f"  [{idx}] TxnID (blank=done): ").strip()
        if not txn_id:
            break
        frm = input(f"  [{idx}] From DateTime : ").strip()
        to  = input(f"  [{idx}] To DateTime   : ").strip()
        amt = input(f"  [{idx}] Amount ₹      : ").strip()
        atm = input(f"  [{idx}] ATM ID        : ").strip()
        loc = input(f"  [{idx}] Location      : ").strip()
        txns.append((txn_id, frm, to, amt, atm, loc))
        idx += 1
    return bank, txns


def generate_cctv_atm(common):
    if "bank_name" not in common:
        bank, txns = collect(common)
    else:
        bank = common["bank_name"]
        txns = [(t["txn_id"], t["from_dt"], t["to_dt"],
                 t["amount"], t["atm_id"], t["location"])
                for t in common["transactions"]]

    doc = new_doc()
    urgent_marking(doc)
    para(doc, "")
    letterhead(doc,
        to_name=f"The Nodal Officer / Cybercell\n{bank}\n[Address]",
        notice_no=common["notice_no"], notice_date=common["notice_date"])

    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(f"Notice to provide CCTV Footage (ATM — {bank}) in FIR No. {common['fir_no']}")
    for r in p.runs:
        r.font.name = FONT; r.font.size = Pt(12)

    para(doc, ""); para(doc, "Sir/Ma'am,"); para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run("Kindly provide CCTV footage for the following ATM transactions:")
    p2.runs[0].font.name = FONT; p2.runs[0].font.size = Pt(12)
    para(doc, "")

    add_table(doc,
        headers=["Sr.", "Txn ID", "From Date-Time", "To Date-Time", "Amount (₹)", "ATM ID", "Location"],
        rows=[(i+1,)+t for i, t in enumerate(txns)],
        col_widths=[0.3, 1.2, 1.3, 1.3, 1.0, 1.0, 1.5])

    para(doc, "")
    brief_facts_block(doc, common["fir_no"], common["ps"], common["district"],
                      common["victim_name"], common["amount"],
                      common["date_of_fir"], common["sections"])

    for pt in [
        "Provide CCTV footage of the ATM cabin/kiosk for the above date-time window.",
        "Preserve the original recording and provide a certified copy.",
        "Comply as per Section 63(4) of the Payment and Settlement Systems Act, 2007.",
        "Do not delete / overwrite any footage pertaining to the above transactions.",
    ]:
        p = doc.add_paragraph(style="List Number")
        p.add_run(pt); p.runs[0].font.name = FONT; p.runs[0].font.size = Pt(12)

    io_block(doc, common["io_name"], common["io_rank"],
             common["io_phone"], common["io_email"], common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/ATM_CCTV_{common['fir_no'].replace('/','_')}_{bank.replace(' ','_')}.docx"
    doc.save(fname)
    return fname
