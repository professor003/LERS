"""Cheque CCTV Notice Generator"""
import os
from docx.shared import Pt
from .base import (new_doc, letterhead, para, brief_facts_block,
                   add_table, io_block, urgent_marking, FONT)


def generate_cctv_cheque(common):
    bank = common.get("bank_name") or input("  Bank Name: ").strip()
    chqs = common.get("cheques") or _collect_cheques()

    doc = new_doc()
    urgent_marking(doc)
    para(doc, "")
    letterhead(doc,
        to_name=f"The Nodal Officer / Cybercell\n{bank}\n[Address]",
        notice_no=common["notice_no"], notice_date=common["notice_date"])

    p = doc.add_paragraph()
    p.add_run("Subject: ").bold = True
    p.add_run(f"Notice to provide CCTV Footage (Cheque — {bank}) in FIR No. {common['fir_no']}")
    for r in p.runs:
        r.font.name = FONT; r.font.size = Pt(12)

    para(doc, ""); para(doc, "Sir/Ma'am,"); para(doc, "")
    p2 = doc.add_paragraph()
    p2.add_run("Kindly provide CCTV footage for the following cheque transactions:")
    p2.runs[0].font.name = FONT; p2.runs[0].font.size = Pt(12)
    para(doc, "")

    rows = [(i+1, c["account_no"], c["ifsc"], c["cheque_no"],
             c["ref_no"], c["txn_date"], c["amount"])
            for i, c in enumerate(chqs)]
    add_table(doc,
        headers=["Sr.", "Account No.", "IFSC", "Cheque No.", "Ref No.", "Txn Date", "Amount (₹)"],
        rows=rows,
        col_widths=[0.3, 1.4, 1.1, 1.1, 1.1, 1.0, 1.0])

    para(doc, "")
    brief_facts_block(doc, common["fir_no"], common["ps"], common["district"],
                      common["victim_name"], common["amount"],
                      common["date_of_fir"], common["sections"])

    for pt in [
        "Provide CCTV footage of the cash counter, lobby, gate, and parking area for the above transactions.",
        "Preserve the original recording and provide a certified copy on CD/DVD/USB.",
        "Comply as per Section 63(4) of the Payment and Settlement Systems Act, 2007.",
        "Do not delete / overwrite any footage pertaining to the above dates.",
    ]:
        p = doc.add_paragraph(style="List Number")
        p.add_run(pt); p.runs[0].font.name = FONT; p.runs[0].font.size = Pt(12)

    io_block(doc, common["io_name"], common["io_rank"],
             common["io_phone"], common["io_email"], common["ps"])

    os.makedirs("output", exist_ok=True)
    fname = f"output/Cheque_CCTV_{common['fir_no'].replace('/','_')}_{bank.replace(' ','_')}.docx"
    doc.save(fname)
    return fname


def _collect_cheques():
    cheques = []
    idx = 1
    while True:
        acc = input(f"  [{idx}] Account No. (blank=done): ").strip()
        if not acc: break
        cheques.append({
            "account_no": acc,
            "ifsc":       input(f"  [{idx}] IFSC       : ").strip(),
            "cheque_no":  input(f"  [{idx}] Cheque No. : ").strip(),
            "ref_no":     input(f"  [{idx}] Ref No.    : ").strip(),
            "txn_date":   input(f"  [{idx}] Txn Date   : ").strip(),
            "amount":     input(f"  [{idx}] Amount ₹   : ").strip(),
        })
        idx += 1
    return cheques
